module.exports = {

    soru1: "İsim yaş?",
    cevap1: "Burak 15",

    soru2: "Sunucuda ne kadar aktifsiniz?",
    cevap2: "13 saat",

    soru3: "Sunucu İçin Neler Yapabilirsiniz?",
    cevap3: "çekiliş, aktiflik vb.",

    soru4: "Daha önce başka sunucuda yetkili oldun mu?",
    cevap4: "5 sunucuda yetkili oldum",

    soru5: "Neden AirCod?",
    cevap5: "Samimi Olduğu için"

}

