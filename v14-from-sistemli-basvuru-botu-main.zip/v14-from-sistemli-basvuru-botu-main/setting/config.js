module.exports = {
    token: "", 
    prefix: "!",
    Footer: "AirCod Team",
    guildID: "1054006695455621200",
    basvuruYt: "1054006695501778990",
    yetkiRolleri: "1054006695476605010",
    logKanalı: "1054006697246588950",
    basvuruDurum: "1054006696382574623"
}

