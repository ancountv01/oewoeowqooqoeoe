# Altyapının Videosu
https://youtu.be/UMBCF1cc7S8

# Kurulum 
`npm i discord.js`
